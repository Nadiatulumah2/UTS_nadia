/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package variabel_tipedata;

/**
 *
 * @author Asus
 */
public class TipeDataString {
    
    public static void main(String[] args) {
        
        String var1 = "Saya sedang belajar ";
        String var2 = "Java";
        String var3 = "Saya belajar\nbahasa Pemrograman \"Java\"";
        
        System.out.print(var1);
        System.out.print(var2);
        System.out.println("");
        System.out.println(var1+var2);
        System.out.println("");
        System.out.println(var3);
    }
}
