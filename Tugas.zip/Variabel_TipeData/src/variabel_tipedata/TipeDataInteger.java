/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package variabel_tipedata;

/**
 *
 * @author Asus
 */
public class TipeDataInteger {
    public static void main(String[] args) {
        
        byte var1;
        short var2;
        int var3;
        long var4;
        
        var1 = 120;
        var2 = 32000;
        var3 = 1000000000;
        var4 = 1000000000000000L;
       
       System.out.println("Var1 = " + var1);
       System.out.println("Var2 = " + var2);
       System.out.println("Var3 = " + var3);
       System.out.println("Var4 = " + var4);
    }
}
